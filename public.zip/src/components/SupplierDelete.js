import React from 'react'

export default function SupplierDelete() {
  return (
    <div>SupplierDelete</div>
  )
}
