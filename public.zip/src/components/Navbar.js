import React, { Component } from 'react'
import { NavLink } from 'react-router-dom'

export default class Navbar extends Component {
  render() {
    return (
      <div className='flex flex-col w-[255px] h-[100vh] bg-[#363740;]'>
        <NavLink style={{textDecoration: "none"}} to={"/clients"}>
          <div >
            <p className='text-base text-[#DDE2FF]'>Clients</p>
          </div>
        </NavLink>
        <NavLink style={{textDecoration: "none"}} to={"/suppliers"}>
          <div >
            <p className='text-base text-[#DDE2FF]'>Suppliers</p>
          </div>
        </NavLink>
      </div>
    )
  }
}