import React from 'react'

export default function SupplierEdit() {
  return (
    <div>SupplierEdit</div>
  )
}
