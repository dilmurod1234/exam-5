import React from 'react'

export default function SupplierModal() {
  return (
    <div>SupplierModal</div>
  )
}
